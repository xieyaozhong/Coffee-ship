(() => {
  'use strict';

  function addStyle() {
    if (document.getElementById('mobileHomeStyle')) return;
    const style = document.createElement('style');
    style.id = 'mobileHomeStyle';
    style.textContent = `
      .quick-help-box,.role-toggle-box{margin-top:12px;border:2px solid rgba(118,83,106,.55);border-radius:16px;background:rgba(18,11,23,.42);overflow:hidden}
      .quick-help-box summary,.role-toggle-box summary{list-style:none;cursor:pointer;padding:12px 14px;font-weight:900;color:#fff4d8}
      .quick-help-box summary::-webkit-details-marker,.role-toggle-box summary::-webkit-details-marker{display:none}
      .quick-help-content,.role-toggle-content{padding:0 14px 14px;color:#d0bfa8;line-height:1.55;font-weight:800}
      .role-toggle-box .role-code-box{margin-top:0!important;padding:0!important;border:0!important;background:transparent!important}
    `;
    document.head.appendChild(style);
  }

  function compactHelp() {
    const creator = document.getElementById('creator');
    const hint = creator && creator.querySelector(':scope > .hint');
    if (!creator || !hint || document.getElementById('quickHelpBox')) return;
    const box = document.createElement('details');
    box.id = 'quickHelpBox';
    box.className = 'quick-help-box';
    box.innerHTML = `<summary>❔ 操作說明</summary><div class="quick-help-content"></div>`;
    box.querySelector('.quick-help-content').textContent = hint.textContent;
    hint.insertAdjacentElement('afterend', box);
  }

  function compactRoleBox() {
    const roleBox = document.querySelector('.role-code-box');
    if (!roleBox || document.getElementById('roleToggleBox')) return;
    const wrapper = document.createElement('details');
    wrapper.id = 'roleToggleBox';
    wrapper.className = 'role-toggle-box';
    wrapper.innerHTML = `<summary>👑 特殊角色登入</summary><div class="role-toggle-content"></div>`;
    roleBox.insertAdjacentElement('beforebegin', wrapper);
    wrapper.querySelector('.role-toggle-content').appendChild(roleBox);
  }

  function renameRandomButton() {
    const btn = document.getElementById('randomAnimalBtn');
    if (btn) btn.textContent = '🎲 隨機冒險';
  }

  function init() {
    addStyle();
    compactHelp();
    renameRandomButton();
    const timer = setInterval(() => {
      compactHelp();
      compactRoleBox();
      renameRandomButton();
    }, 300);
    setTimeout(() => clearInterval(timer), 8000);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
